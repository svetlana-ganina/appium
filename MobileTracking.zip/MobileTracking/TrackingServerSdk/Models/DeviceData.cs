﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace TrackingServerSdk.Models
{
    [Description("The data about a device")]
    public class DeviceData
    {
        [Description("The name of the operating system running on the device")]
        public string OsName { get; set; }
        [Description("The version of the operating system running on the device")]
        public string OsVersion { get; set; }
        [Description("The device type")]
        public string DeviceModel { get; set; }
        [Description("The country set in the device.")]
        public string DeviceCountry { get; set; }
        [Description("The locale set in the device.")]
        public string DeviceLocale { get; set; }
        [Description("The screen resolution used by the device")]
        public string ScreenResolution { get; set; }
        [Description("The network carrier used by the device")]
        public string Carrier { get; set; }
        [Description("The date at which this device data was collected")]
        public DateTime? RegistrationDate { get; set; }
        [Description("Extra details a device might need to capture.")]
        public DataDictionary Details { get; set; }
    }
}
