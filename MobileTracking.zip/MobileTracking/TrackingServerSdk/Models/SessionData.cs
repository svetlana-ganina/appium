﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.ComponentModel;

namespace TrackingServerSdk.Models
{
    [Description("The data about a session")]
    public class SessionData
    {
        [Description("The date at which the session began.")]
        public DateTime? Start { get; set; }

        [Description("The date at which the session ended.")]
        public DateTime? End { get; set; }

        [Description("A flag indicating if the device is currently using wifi")]
        public bool? Wifi { get; set; }

        [Description("A string indicating the app version the device is running")]
        public string AppVersion { get; set; }
    }
}
