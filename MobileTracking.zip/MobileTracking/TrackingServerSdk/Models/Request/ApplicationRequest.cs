﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ServiceStack.Common.Web;
using ServiceStack.ServiceHost;
using TrackingServerSdk.Models.Response;

namespace TrackingServerSdk.Models.Request
{
    [Route("/analytics/application/{Id}", HttpMethods.Get)]
    public class ApplicationRequest : BaseRequest<ApplicationResponse>
    {
        public Guid Id { get; set; }
    }
}
