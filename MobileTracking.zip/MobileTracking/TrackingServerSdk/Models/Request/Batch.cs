﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;
using ServiceStack.Common.Web;
using ServiceStack.ServiceHost;
using TrackingServerSdk.Models.Response;

namespace TrackingServerSdk.Models.Request
{
    [Description("Record a batch of analytic events")]
    [Route("/analytics/batch", HttpMethods.Post)]
    public class Batch : BaseRequest<BatchResponse>
    {
        [Description("The batch Id to track batch messages that have been processed by the workflow")]
        public Guid Id { get; set; }
        [Description("The UTC datetime of the client device at the time the Batch is sent.")]
        public DateTime DeviceSendDate { get; set; }
        [Description("The device on which the events occured")]
        public Models.Device Device { get; set; }
        [Description("The application on which the events occured")]
        public Application Application { get; set; }
        [Description("The sessions that wrap the events")]
        public List<Models.Session> Sessions { get; set; }
    }
}
