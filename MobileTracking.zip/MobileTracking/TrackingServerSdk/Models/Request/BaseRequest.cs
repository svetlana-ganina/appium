﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System.ComponentModel;
using ServiceStack.ServiceHost;
using TrackingServerSdk.Models.Response;

namespace TrackingServerSdk.Models.Request
{
    [Description("The base request class, from which all requests should derive.")]
    public abstract class BaseRequest<T> : IReturn<T> where T : BaseResponse
    {
    }
}
