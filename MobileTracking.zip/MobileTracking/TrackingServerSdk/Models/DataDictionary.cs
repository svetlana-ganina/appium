﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace TrackingServerSdk.Models
{
    [CollectionDataContract(Name="DataNodes", ItemName="Node", KeyName="Key", ValueName="Value")]
    public class DataDictionary : Dictionary<string, string>
    {
        public DataDictionary() {}
        public DataDictionary(Dictionary<string, string> dictionary) : base(dictionary){}
    }
}
