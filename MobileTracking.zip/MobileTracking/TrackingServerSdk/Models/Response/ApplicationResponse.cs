﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TrackingServerSdk.Models.Response
{
    public class ApplicationResponse : BaseResponse
    {
        public Guid Id { get; set; }
        public string Name { get; set; }
        public int BatchSize { get; set; }
        public bool SendSessionEnd { get; set; }
        public bool SendPrevSessionExists { get; set; }
    }
}
