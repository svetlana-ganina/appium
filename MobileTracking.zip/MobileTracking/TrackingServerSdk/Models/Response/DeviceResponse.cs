﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.ComponentModel;

namespace TrackingServerSdk.Models.Response
{
    [Description("The response for a device request")]
    public class DeviceResponse : BaseResponse
    {
        [Description("The id of the device.")]
        public Guid Id { get; set; }
    }
}
