﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.Collections.Generic;
using System.ComponentModel;

namespace TrackingServerSdk.Models.Response
{
    [Description("The response fired when batched data is sent.")]
    public class BatchResponse : BaseResponse
    {
        [Description("The id of the device recorded in this batch.")]
        public Guid DeviceId { get; set; }
        [Description("The id of the application recorded in this batch.")]
        public Guid ApplicationId { get; set; }
        [Description("The isd of the sessions recorded in this batch, in the same order that they were received.")]
        public List<Guid> SessionIds { get; set; }
    }
}
