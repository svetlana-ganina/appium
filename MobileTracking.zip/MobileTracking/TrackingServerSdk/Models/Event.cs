﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.ComponentModel;

namespace TrackingServerSdk.Models
{
    [Description("Represents a single analytic event")]
    public class Event
    {
        public Event()
        {
            // This will generate the current time.
            // If a date is provided through the service this value will be overwritten.
            Date = DateTime.UtcNow;
        }

        [Description("The date and time for the event. If not provided, this will be set to the server time.")]
        public DateTime Date { get; set; }
        [Description("The type of event that occured.")]
        public string EventType { get; set; }
        [Description("The set of data associated to the event")]
        public DataDictionary Data { get; set; }
    }
}