﻿#region File Header
// /*************************************************************************
//  * 
//  * © Copyright 2013 Fuel Industries Incorporated
//  * All Rights Reserved.
//  * 
//  * NOTICE:  All information contained herein is, and remains
//  * the property of Fuel Industries Incorporated
//  * The intellectual and technical concepts contained herein
//  * are proprietary to Fuel Industries Incorporated
//  * Dissemination of this information or reproduction of this material
//  * is strictly forbidden unless prior written permission is obtained
//  * from Fuel Industries Incorporated
//  *
//  *************************************************************************/
#endregion

using System;
using System.ComponentModel;

namespace TrackingServerSdk.Models
{
    [Description("An application that can be used for analytic tracking.\n")]
    public class Application
    {
        [Description("The ID of the application. If not provided, this will be set by the server.")]
        public Guid Id { get; set; }
        [Description("The default batch size.  Used as a configuration option for client devices.")]
        public int BatchSize { get; set; }
        [Description("A flag to know if client device should send data when a session ends.")]
        public bool SendSessionEnd { get; set; }
        [Description("A flag to know if a client device should send data if a previous session exists.")]
        public bool SendPrevSessionExists { get; set; }
    }
}
