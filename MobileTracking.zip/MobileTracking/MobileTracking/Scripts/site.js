﻿site = {
    home: {
        init: function() {
            site.home._eventsTable = $("#events-table");
            $('#date-time').datetimepicker();
            $("#start-btn").click(function() {
                site.home._isUpdate = true;
                site.home._deviceId = $("#device-id").val();
                site.home._startTime = $("#date-time input").val()
                    ? $("#date-time").data("DateTimePicker").getDate().format("YYYY-MM-DD HH:mm:ss")
                    : null;
                if (site.home._deviceId) {
                    $("#start-btn").addClass("disabled");
                    $("#stop-btn").removeClass("disabled");
                    site.home.start(site.home._deviceId, site.home._startTime);
                } else {
                    alert("Please specify Device Id");
                }
            });
            $("#stop-btn").click(function() {
                site.home._isUpdate = false;
                $("#start-btn").removeClass("disabled");
                $("#stop-btn").addClass("disabled");
            });
            $("#clear-btn").click(function() {
                site.home.displayEvents(null);
                //                $("#date-time input").val("");
                //                site.home._startTime = null;
                //                site.home._lastEventDate = null;
                //                if (site.home._isUpdate) {
                //                    site.home.start(site.home._deviceId, site.home._startTime);
                //                }
            });
            $("#submit-btn").click(function() {
                var deviceId = $("#device-id").val();
                var startTime = $("#date-time input").val();
                if (!deviceId) {
                    alert("Device Id is required");
                } else if (!startTime) {
                    alert("Start Time is required");
                } else {
                    $("#submit-btn").addClass("disabled");
                    startTime = $("#date-time").data("DateTimePicker").getDate().format("YYYY-MM-DD HH:mm:ss");
                    site.home.requestEvents(deviceId, startTime, function(data) {
                        $("#submit-btn").removeClass("disabled");
                        site.home.displayEvents(data.Events);
                    });
                }
            });
        },
        start: function(deviceId, startTime) {
            $.getJSON("Home/Start", {
                deviceId: deviceId,
                startTime: startTime
            }, function(data) {
                site.home._lastEventDate = data.LastEventDate;
                site.home.update(data.DeviceId, data.LastEventDate, data.IsStartTimeSet);
            });
        },
        update: function(deviceId, lastEventDate, isStartTimeSet) {
            $.getJSON("Home/Update", {
                deviceId: deviceId,
                lastEventDate: lastEventDate,
                IsStartTimeSet: isStartTimeSet
            }, function(data) {
                if (site.home._isUpdate && site.home._lastEventDate == data.LastEventDate) {
                    site.home.displayEvents(data.Events);
                    setTimeout(function() {
                        site.home.update(deviceId, lastEventDate, isStartTimeSet);
                    }, 1000);
                }
            });
        },
        requestEvents: function(deviceId, startTime, callback) {
            $.getJSON("Home/GetEvents", {
                deviceId: deviceId,
                startTime: startTime
            }, callback);
        },
        //        requestSQS: function (callback) {
        //            var sqs = new AWS.SQS({
        //                endpoint: "https://sqs.eu-west-1.amazonaws.com",
        //                region: "eu-west-1",
        //                accessKeyId: "AKIAIDUMWDWQCS5E5KUA",
        //                secretAccessKey: "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"
        //            });
        //            sqs.receiveMessage({
        //                QueueUrl: "https://sqs.eu-west-1.amazonaws.com/578644788507/analytics-qa-queue",
        //                AttributeNames: ["All"],
        //                MaxNumberOfMessages: 10,
        //                VisibilityTimeout: 0,
        //                WaitTimeSeconds: 0
        //            }, function (error, data) {
        //                callback(site.home.parseSQSData(data));
        //            });
        //        },
        //        parseSQSData: function (data) {
        //            var events = [];
        //            if (data && data.Messages) {
        //                for (var i = 0; i < data.Messages.length; i++) {
        //                    var bodyStr = data.Messages[i].Body;
        //                    var body;
        //                    try {
        //                        body = JSON.stringify(bodyStr);
        //                    } catch (error) {
        //                        // Sometimes body string is incorrect
        //                        try {
        //                            body = JSON.stringify(bodyStr + "]}]}");
        //                        } catch (error) {
        //                            alert(error + "\n" + bodyStr);
        //                            continue;
        //                        }
        //                    }
        //                    if (body.Sessions) {
        //                        for (var j = 0; j < body.Sessions.length; j++) {
        //                            var session = body.Sessions[j];
        //                            if (session.Events) {
        //                                for (var k = 0; k < session.Events.length; k++) {
        //                                    session.Events[k].InQueue = true;
        //                                    events.push(session.Events[k]);
        //                                }
        //                            }
        //                        }
        //                    }
        //                }
        //            }
        //            return events;
        //        },
        displayEvents: function(events) {
            if (events && events.length > 0) {
                for (var i = 0; i < events.length; i++) {
                    events[i].Date = events[i].Date.replace(/\.\d+$/, "");
                }
                var count = events.length;
                var index = 0;
                var setRow = function(td, event) {
                    $(td.get(0)).text(event.EventType);
                    $(td.get(1)).text(event.Date);
                    $(td.get(2)).text(event.Data);
                    $(td.get(3)).text(event.InQueue ? "Queue" : "Database");
                }
                // Update existing rows
                site.home._eventsTable
                    .find("tr")
                    .not(":first")
                    .filter(":lt(" + count + ")")
                    .each(function() {
                        setRow($(this).children("td"), events[index]);
                        index++;
                    });
                // Remove extra rows
                site.home._eventsTable
                    .find("tr")
                    .not(":first")
                    .filter(":gt(" + (count - 1) + ")")
                    .remove();
                // Add required rows
                for (; index < count; index++) {
                    var tr = $("<tr><td></td><td></td><td></td><td></td></tr>");
                    setRow(tr.find("td"), events[index]);
                    site.home._eventsTable.append(tr);
                }
            } else {
                site.home._eventsTable
                    .find("tr")
                    .not(":first")
                    .remove();
            }
        }
    }
}