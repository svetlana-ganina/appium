﻿using System.Data.Entity;
using MobileTracking.Data.Models;
using MySql.Data.Entity;

namespace MobileTracking.Data
{
    [DbConfigurationType(typeof(MySqlEFConfiguration))]
    public class TrackingQA : DbContext
    {
        public virtual DbSet<Application> Applications { get; set; }
        public virtual DbSet<Batch> Batches { get; set; }
        public virtual DbSet<Device> Devices { get; set; }
        public virtual DbSet<Event> Events { get; set; }
        public virtual DbSet<Session> Sessions { get; set; }

        static TrackingQA()
        {
            // NO auto migrations
            Database.SetInitializer<TrackingQA>(null);
        }

        public TrackingQA()
            : base("TrackingQA")
        {
        }
    }
}