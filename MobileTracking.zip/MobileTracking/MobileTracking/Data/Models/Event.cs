﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobileTracking.Data.Models
{
    [Table("Events")]
    public class Event : BaseModel
    {
        public string SessionId { get; set; }
        public string EventType { get; set; }
        public DateTime? Date { get; set; }
        public string Data { get; set; }

        [ForeignKey("SessionId")]
        public virtual Session Session { get; set; }
    }
}