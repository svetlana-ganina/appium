﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobileTracking.Data.Models
{
    [Table("Batches")]
    public class Batch : BaseModel
    {
        public DateTime? DeviceSendDate { get; set; }
        public DateTime? QueueSendDate { get; set; }
    }
}