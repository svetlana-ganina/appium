﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobileTracking.Data.Models
{
    [Table("Sessions")]
    public class Session : BaseModel
    {
        public string ApplicationId { get; set; }
        public string DeviceId { get; set; }
        public DateTime? Start { get; set; }
        public DateTime? End { get; set; }
        public bool? Wifi { get; set; }
        public string AppVersion { get; set; }

        [ForeignKey("ApplicationId")]
        public virtual Application Application { get; set; }

        [ForeignKey("DeviceId")]
        public virtual Device Device { get; set; }
    }
}