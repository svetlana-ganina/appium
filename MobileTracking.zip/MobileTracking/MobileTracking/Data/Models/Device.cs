﻿using System;
using System.ComponentModel.DataAnnotations.Schema;

namespace MobileTracking.Data.Models
{
    [Table("Devices")]
    public class Device : BaseModel
    {
        public string OsName { get; set; }
        public string OsVersion { get; set; }
        public string DeviceModel { get; set; }
        public string DeviceCountry { get; set; }
        public string DeviceLocale { get; set; }
        public string ScreenResolution { get; set; }
        public string Carrier { get; set; }
        public string Details { get; set; }
        public DateTime? RegistrationDate { get; set; }
    }
}