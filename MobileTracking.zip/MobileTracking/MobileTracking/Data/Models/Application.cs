﻿using System.ComponentModel.DataAnnotations.Schema;

namespace MobileTracking.Data.Models
{
    [Table("Applications")]
    public class Application : BaseModel
    {
        public string Name { get; set; }
        public int? BatchSize { get; set; }
        public bool? SendSessionEnd { get; set; }
        public bool? SendPrevSessionExists { get; set; }
    }
}