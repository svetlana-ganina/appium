﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Web.Mvc;
using log4net;
using MobileTracking.Data;
using MobileTracking.Sqs;
using Newtonsoft.Json;
using TrackingServerSdk.Models.Request;

namespace MobileTracking.Controllers
{
    public class HomeController : Controller
    {
        private ILog Log = LogManager.GetLogger(typeof(HomeController));

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Start(string deviceId, string startTime)
        {
            using (var context = new TrackingQA())
            {
                DateTime lastEventDate;
                bool isStartTimeSet = false;
                if (context.Events.Any(e => e.Session.DeviceId == deviceId))
                {
                    if (!string.IsNullOrEmpty(startTime))
                    {
                        var startDate = DateTime.ParseExact(startTime, "yyyy-MM-dd HH:mm:ss",
                            CultureInfo.InvariantCulture);
                        lastEventDate = context.Events
                            .Where(e => e.Session.DeviceId == deviceId)
                            .Where(e => e.Date >= startDate)
                            .Min(e => e.Date)
                            .GetValueOrDefault(startDate);
                        isStartTimeSet = true;
                    }
                    else
                    {
                        lastEventDate = context.Events
                            .Where(e => e.Session.DeviceId == deviceId)
                            .Max(e => e.Date)
                            .GetValueOrDefault(DateTime.MinValue);
                    }
                }
                else
                {
                    lastEventDate = new DateTime(0);
                }
                return Json(new
                {
                    DeviceId = deviceId,
                    LastEventDate = lastEventDate.Ticks,
                    IsStartTimeSet = isStartTimeSet
                }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult Update(string deviceId, long lastEventDate, bool isStartTimeSet)
        {
            using (var context = new TrackingQA())
            {
                var lastDate = new DateTime(lastEventDate);
                var events = context.Events
                    .Where(e => e.Session.DeviceId == deviceId)
                    .Where(e => isStartTimeSet ? e.Date >= lastDate : e.Date > lastDate)
                    .OrderBy(e => e.Date)
                    .Select(e => new EventViewModel
                    {
                        EventType = e.EventType,
                        Date = e.Date.ToString(),
                        Data = e.Data
                    })
                    .ToList();
                return Json(new
                {
                    DeviceId = deviceId,
                    LastEventDate = lastEventDate,
                    Events = events
                }, JsonRequestBehavior.AllowGet);
            }
        }

        public ActionResult GetEvents(string deviceId, string startTime)
        {
            DateTime startDate;
            if (!string.IsNullOrEmpty(startTime))
            {
                try
                {
                    startDate = DateTime.ParseExact(startTime, "yyyy-MM-dd HH:mm:ss", CultureInfo.InvariantCulture);
                }
                catch (Exception e)
                {
                    startDate = DateTime.UtcNow;
                }
            }
            else
            {
                startDate = DateTime.UtcNow;
            }

            Guid deviceGuid;
            try
            {
                deviceGuid = Guid.Parse(deviceId);
            }
            catch (Exception e)
            {
                deviceGuid = Guid.Empty;
            }

            var amazonEvents = GetAmazonEvents(deviceGuid, startDate);
            var databaseEvents = GetDatabaseEvents(deviceGuid, startDate);

            var events = amazonEvents.Concat(databaseEvents)
                .OrderByDescending(e => e.Date)
                .ToList();

            return Json(new
            {
                DeviceId = deviceId,
                StartDate = startDate.ToString(),
                Events = events
            }, JsonRequestBehavior.AllowGet);
        }

        private IEnumerable<EventViewModel> GetDatabaseEvents(Guid deviceGuid, DateTime startDate)
        {
            using (var context = new TrackingQA())
            {
                var deviceId = deviceGuid.ToString("N");
                return context.Events
                    .Where(e => e.Session.DeviceId == deviceId)
                    .Where(e => e.Date >= startDate)
                    .ToList()
                    .Select(e => new EventViewModel
                    {
                        EventType = e.EventType,
                        Date = e.Date.GetValueOrDefault().ToString("yyyy-MM-dd HH:mm:ss"),
                        Data = e.Data,
                        InQueue = false
                    })
                    .ToList();
            }
        }

        private IEnumerable<EventViewModel> GetAmazonEvents(Guid deviceGuid, DateTime startDate)
        {
            var list = new List<EventViewModel>();
            foreach (var message in new QueueQA().GetMessages())
            {
                Batch batch;
                try
                {
                    batch = JsonConvert.DeserializeObject<Batch>(message.Body);
                }
                catch (Exception e)
                {
                    Log.ErrorFormat("Could not serialize [{0}] to Batch object.", message.Body);
                    continue;
                }
                if (batch.Device.Id == deviceGuid)
                {
                    foreach (var session in batch.Sessions)
                    {
                        list.AddRange(session.Events
                            .Where(e => e.Date >= startDate)
                            .Select(e => new EventViewModel
                            {
                                EventType = e.EventType,
                                Date = e.Date.ToString("yyyy-MM-dd HH:mm:ss"),
                                Data = JsonConvert.SerializeObject(e.Data),
                                InQueue = true
                            }));
                    }
                }
            }
            return list;
        }

        [JsonObject]
        private class EventViewModel
        {
            public string EventType { get; set; }
            public string Date { get; set; }
            public string Data { get; set; }
            public bool InQueue { get; set; }
        }
    }
}