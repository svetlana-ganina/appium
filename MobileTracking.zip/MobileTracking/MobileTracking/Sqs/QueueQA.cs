﻿using System.Collections.Generic;
using Amazon.SQS;
using Amazon.SQS.Model;

namespace MobileTracking.Sqs
{
    public class QueueQA
    {
        public List<Message> GetMessages()
        {
            var config = new AmazonSQSConfig { ServiceURL = "https://sqs.eu-west-1.amazonaws.com" };
            var client = new AmazonSQSClient(config);
            var response = client.ReceiveMessage(new ReceiveMessageRequest
            {
                QueueUrl = "https://sqs.eu-west-1.amazonaws.com/578644788507/analytics-qa-queue",
                MaxNumberOfMessages = 10,
                VisibilityTimeout = 0,
                WaitTimeSeconds = 0,
                AttributeNames = new List<string> { "All" }
            });
            return response.Messages;
        }
    }
}