namespace MobileTracking.Migrations
{
    using System.Data.Entity.Migrations;
    
    internal sealed class Configuration : DbMigrationsConfiguration<MobileTracking.Data.TrackingQA>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }
    }
}
