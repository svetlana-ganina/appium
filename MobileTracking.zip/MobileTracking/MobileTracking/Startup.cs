﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MobileTracking.Startup))]
namespace MobileTracking
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
